a=float(input("enter a value"))
b=float(input("enter b value"))
temp=a
a=b
b=temp
print("a=",a)
print("b=",b)

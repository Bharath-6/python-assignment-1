a=int(input("enter the value of a "))
b=int(input("enter the value of b "))
c=a+b
d=a-b
e=a*b
f=a/b
g=a**b
h=a%b
i=a//b
print("the sum is",c)
print("the difference is",d)
print("product is",e)
print("division is",f)
print("power is",g)
print("remainder is",h)
print("quotient is",i)

PI = 3.14
radius = float(input(' Please Enter the radius of a circle: '))
area = PI * radius * radius
print(" Area Of a Circle = %.2f" %area)



p= float(input("enter the value of  principle p"))

r= float(input("enter  the value of  rate of interest r "))
t= float(input("enter the value of time t"))


SI = (p * r * t) /100

print("simple interest is", SI)
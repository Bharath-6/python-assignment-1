PI = 3.14
radius = float(input(' Please Enter the radius of a circle: '))
circumference = 2 * PI * radius
print(" Circumference Of a Circle = %.2f" %circumference)
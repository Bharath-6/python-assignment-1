a=float(input('enter the value of first side:'))
b=float(input('enter the value of second side:'))
c=float(input('enter the value of third side:'))
s=(a+b+c)/2
area=s*(s-a)*(s-b)*(s-c)**0.5
print('The area of the triangle is %0.2f' %area)
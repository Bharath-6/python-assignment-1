  
h=float(input("enter height of triangle"))
w=float(input("enter width of triangle"))
a=0.5*w*h
print=("area of triangle is ",a)
